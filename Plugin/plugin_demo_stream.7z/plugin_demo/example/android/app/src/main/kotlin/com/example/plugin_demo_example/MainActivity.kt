package com.example.plugin_demo_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
