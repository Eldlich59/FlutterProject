//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <plugin_demo/plugin_demo_plugin_c_api.h>

void RegisterPlugins(flutter::PluginRegistry* registry) {
  PluginDemoPluginCApiRegisterWithRegistrar(
      registry->GetRegistrarForPlugin("PluginDemoPluginCApi"));
}
